﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using TMPro;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    static GameManager _instance;
    public static GameManager instance
    {
        get
        {
            if(_instance == null)
            {
                GameObject manager = new GameObject("GameManager");
                _instance = manager.AddComponent<GameManager>();
                DontDestroyOnLoad(manager);
            }
            return _instance;
        }
    }

    void Awake()
    {
        if(_instance == null)
        {
            _instance = this;
            DontDestroyOnLoad(this);
        }
        else
        {
            if(this != _instance) { Destroy(this.gameObject); }
        }
    }


    public int score = 0;
    public int lives = 3;
    public int timer = 300;

    public Text scoreText;
    public Text livesText;
    public Text timerText;

    //displays titles before value is displayed
    public string scoreStart = "default";
    public string livesStart = "default";
    public string timerStart = "default";

    public int scoreDefault;
    public int livesDefault;

    public bool canBeatLevel = false;
    public int beatLevelScore = 1;

    public bool timedLevel = false;
    public int startTime = 300;

    public GameObject player;

    public AudioSource backgroundMusic;
    public AudioSource gameOverSfx;
    public AudioSource beatLevelSfx;

    public enum gameStates { Playing, Death, GameOver, Beatlevel };
    public gameStates state;

    public bool gameIsOver = false;
    public bool playerIsDead = false;

    public Canvas MenuCanvas;
    public Canvas HUBCanvas;
    public Canvas EndScreenCanvas;
    public Canvas FooterCanvas;

    public Text endMessageDisplay;
    public Text gameOver;
    public Text gameTitle;
    public Text gameCredits;
    public Text gameCopyright;

    public string endMessageDisplayWin = "World is saved and everyone is happy :)";
    public string endMessageDisplayLose = "Butts the Clown took over the world and made everyone sad :(";
    public string gameOverString = "Game Over";
    public string gameTitleString = "Bear McGrizz";
    public string gameCreditsString = "Credits: Guy Who Did Everything- Michael Segnar";
    public string gameCopyrightString = "Created by NutMuffin Games(c)";

    String firstLevel = "TheScene";
    String nextLevel = "ExtraScene";
    String levelToLoad;
    String currentLevel;

    public int currentTime = 300;

    public bool gameStarted = false;
    public bool replay = false;

    public string copyright = System.DateTime.Now.ToString("yyyy");

    public int subTimer = 60;
    public int LVLcount = Application.levelCount;

    bool bgOver = false;

    void Reset()
    {
        score = 0;
        lives = 3;
        timer = 300;
        canBeatLevel = false;
        beatLevelScore = 1;
        timedLevel = false;
        startTime = 300;
        gameIsOver = false;
        playerIsDead = false;
        currentTime = 300;
        gameStarted = false;
        replay = false;
        copyright = System.DateTime.Now.ToString("yyyy");
        subTimer = 60;
    }


    void HideMenu()
    {
        MenuCanvas.enabled = false;
        HUBCanvas.enabled = false;
        EndScreenCanvas.enabled = false;
        FooterCanvas.enabled = false;
    }
    // Start is called before the first frame update
    void Start()
    {
        HideMenu();
        levelToLoad = firstLevel;
        PlayGame();
    }

    public void MainMenu()
    {
        scoreDefault = 0;
        livesDefault = 3;

        score = scoreDefault;
        lives = livesDefault;

        gameTitle.text = gameTitleString;
        gameCredits.text = gameCreditsString;
        gameCopyright.text = gameCopyrightString;

        MenuCanvas.enabled = true;
        FooterCanvas.enabled = true;
    }

    public void Quit()
    {
        Application.Quit();
    }

    public void PlayGame()
    {
        MenuCanvas.enabled = false;
        FooterCanvas.enabled = false;
        HUBCanvas.enabled = true;

        if(timedLevel)
        {
            currentTime = startTime;
            timerText.text = currentTime.ToString();
        }

        scoreText.text = score.ToString();

        livesText.text = lives.ToString();

        gameStarted = true;

        state = gameStates.Playing;

        playerIsDead = false;

        SceneManager.LoadScene(levelToLoad, LoadSceneMode.Additive);

        currentLevel = levelToLoad;
    }
    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Q) == true)
        {
            playerIsDead = true;
        }
        if (Input.GetKeyDown(KeyCode.W) == true)
        {
            canBeatLevel = true;
        }
        if (Input.GetKeyDown(KeyCode.E) == true)
        {
            gameIsOver = true;
        }

        else if (Input.GetKeyDown(KeyCode.Y) == true)
        {
            state = gameStates.GameOver;
        }

        scoreText.text = score.ToString();
        livesText.text = lives.ToString();

        switch(state)
        {
            case gameStates.Playing:
                    if (playerIsDead)
                    {
                       if(lives > 0)
                    {
                        lives--;
                        RestartLevel();
                    }
                    else
                    {
                        state = gameStates.Death;
                    }
                }
                    

                    if (canBeatLevel && beatLevelScore >= 1)
                    {
                        state = gameStates.Beatlevel;
                    }

                    if (timedLevel)
                    {
                        if (currentTime < 0)
                        {
                            state = gameStates.GameOver;
                        }
                        else
                        {
                            subTimer--;
                            if (subTimer <= 0)
                            {
                                subTimer = 60;
                                timer--;
                            }
                            timerText.text = timer.ToString();
                        }
                    }
                break;
            case gameStates.Death:
                if(backgroundMusic != null)
                {
                    backgroundMusic.volume = 0;
                    bgOver = true;

                    if (bgOver || backgroundMusic == null)
                    {
                        if (gameOverSfx != null)
                        { gameOverSfx.Play(); }
                        state = gameStates.GameOver;
                        endMessageDisplay.text = endMessageDisplayLose;
                    }
                }
                break;
            case gameStates.Beatlevel:
                if(backgroundMusic != null)
                {
                    backgroundMusic.volume = 0;
                    bgOver = true;

                    if (bgOver || backgroundMusic == null)
                    {
                        if (gameOverSfx != null)
                        { gameOverSfx.Play(); }
                        if (currentLevel != nextLevel)
                        {
                            StartNextLevel();
                        }
                        else
                        {
                            endMessageDisplay.text = endMessageDisplayWin;
                            state = gameStates.GameOver;
                        }
                    }
                }    
                break;
            case gameStates.GameOver:
                player.SetActive(false);
                HUBCanvas.enabled = false;
                EndScreenCanvas.enabled = true;
                FooterCanvas.enabled = true;
                gameOver.text = gameOverString;
                break;
        }
    }
    
    public void RestartLevel()
    {
        playerIsDead = false;
        SceneManager.UnloadSceneAsync(currentLevel);
        PlayGame();
    }

    public void StartNextLevel()
    {
        bgOver = false;
        lives = livesDefault;
        SceneManager.UnloadSceneAsync(currentLevel);
        levelToLoad = nextLevel;
        PlayGame();
    }

    public void RestartGame()
    {
        score = scoreDefault;
        lives = livesDefault;
        SceneManager.UnloadSceneAsync(currentLevel);
        levelToLoad = firstLevel;
        PlayGame();
    }
}
